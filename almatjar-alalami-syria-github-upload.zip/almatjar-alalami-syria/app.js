const toast = document.querySelector("#toast");
const searchForm = document.querySelector("#search-form");
const searchInput = document.querySelector("#search-input");
const provinceFilter = document.querySelector("#province-filter");
const shippingFilter = document.querySelector("#shipping-filter");
let toastTimer;

function showToast(message) {
  toast.textContent = message;
  toast.classList.add("show");
  window.clearTimeout(toastTimer);
  toastTimer = window.setTimeout(() => toast.classList.remove("show"), 2400);
}

searchForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const query = searchInput.value.trim();
  const province = provinceFilter.value;
  const shipping = shippingFilter.value;
  const scope = [province !== "كل المحافظات" ? `في ${province}` : "", shipping !== "كل الخيارات" ? `بشحن ${shipping}` : ""].filter(Boolean).join("، ");
  showToast(query ? `سنبحث عن «${query}»${scope ? ` ${scope}` : ""} عند اكتمال الكتالوج.` : "اكتب اسم المنتج أو القسم للبحث.");
});

document.querySelectorAll(".role-card").forEach((card) => {
  card.addEventListener("click", () => {
    if (card.classList.contains("locked")) {
      showToast("قسم المتجر الكبير سيُفعّل في مرحلة لاحقة.");
      return;
    }
    document.querySelectorAll(".role-card").forEach((item) => item.classList.remove("selected"));
    card.classList.add("selected");
    const smallWorkspace = document.querySelector("#workspace");
    const largeWorkspace = document.querySelector("#large-workspace");
    smallWorkspace.hidden = card.dataset.role !== "small";
    largeWorkspace.hidden = card.dataset.role !== "large";
    if (card.dataset.role === "small") {
      smallWorkspace.scrollIntoView({ behavior: "smooth", block: "start" });
      showToast("مساحة المتجر الصغير قيد التجهيز.");
    } else if (card.dataset.role === "large") {
      largeWorkspace.scrollIntoView({ behavior: "smooth", block: "start" });
      showToast("تم اعتماد مساحة المتجر الكبير للنسخة الأولى.");
    } else {
      showToast("أنت الآن في مساحة المشتري.");
    }
  });
});

document.querySelectorAll("[data-soon]").forEach((button) => {
  button.addEventListener("click", () => showToast(button.dataset.soon));
});

document.querySelector("#cart-button").addEventListener("click", () => showToast("السلة فارغة الآن؛ أضف منتجات عند فتح الكتالوج."));

const promotionForm = document.querySelector("#promotion-form");
const promotionStoreType = document.querySelector("#promotion-store-type");
const promotionPriceValue = document.querySelector("#promotion-price-value");
const promotionItem = document.querySelector("#promotion-item");
const promotionDuration = document.querySelector("#promotion-duration");

function getPromotionPrice() {
  return promotionStoreType?.value === "large" ? 10 : 1;
}

function refreshPromotionPrice() {
  if (promotionPriceValue) promotionPriceValue.textContent = `${getPromotionPrice()} دولار`;
}

promotionStoreType?.addEventListener("change", refreshPromotionPrice);
promotionForm?.addEventListener("submit", (event) => {
  event.preventDefault();
  const item = promotionItem?.value.trim();
  const duration = Number(promotionDuration?.value);
  if (!item || !Number.isInteger(duration) || duration < 1 || duration > 30) {
    showToast("أدخل معرّف العرض ومدة صحيحة بين يوم و30 يومًا.");
    return;
  }
  const selectedPayment = document.querySelector('input[name="promotion-payment"]:checked')?.value || "manual";
  if (selectedPayment !== "manual") {
    showToast("Sham Cash وiCash غير مفعّلين حاليًا؛ اختر الدفع اليدوي.");
    return;
  }
  const request = {
    id: `local-${Date.now()}`,
    item,
    storeType: promotionStoreType.value,
    priceUsd: getPromotionPrice(),
    durationDays: duration,
    paymentProvider: selectedPayment,
    status: "pending",
    createdAt: new Date().toISOString(),
  };
  const previous = JSON.parse(localStorage.getItem("almatjar-promotion-requests") || "[]");
  localStorage.setItem("almatjar-promotion-requests", JSON.stringify([request, ...previous].slice(0, 20)));
  showToast(`تم إرسال طلب الترويج بسعر ${request.priceUsd} دولار للمراجعة اليدوية.`);
  promotionForm.reset();
  refreshPromotionPrice();
});

const consent = document.querySelector("#legal-consent");
const loginButton = document.querySelector("#login-button");
loginButton.addEventListener("click", () => {
  showToast(consent.checked ? "سيتم ربط تسجيل الدخول الآمن في المرحلة الخلفية." : "يرجى الموافقة على الشروط وإخلاء المسؤولية أولًا.");
});

const drawer = document.querySelector("#side-drawer");
const drawerToggle = document.querySelector("#drawer-toggle");
const drawerClose = document.querySelector("#drawer-close");
const drawerBackdrop = document.querySelector("#drawer-backdrop");

function setDrawer(open) {
  if (!drawer || !drawerToggle || !drawerBackdrop) return;
  drawer.classList.toggle("open", open);
  drawer.setAttribute("aria-hidden", String(!open));
  drawerToggle.setAttribute("aria-expanded", String(open));
  drawerBackdrop.hidden = !open;
  if (open) drawerClose?.focus();
  else drawerToggle.focus();
}

drawerToggle?.addEventListener("click", () => setDrawer(true));
drawerClose?.addEventListener("click", () => setDrawer(false));
drawerBackdrop?.addEventListener("click", () => setDrawer(false));
drawer?.querySelectorAll("a").forEach((link) => link.addEventListener("click", () => setDrawer(false)));
document.addEventListener("keydown", (event) => {
  if (event.key === "Escape" && drawer?.classList.contains("open")) setDrawer(false);
});
