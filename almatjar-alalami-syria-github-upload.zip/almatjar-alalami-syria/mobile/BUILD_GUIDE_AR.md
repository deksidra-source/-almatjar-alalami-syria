# بناء تطبيق المتجر العالمي سوريا لأندرويد وآيفون

هذا المجلد مستقل بالكامل عن مشروع «سوقنا سوريا». اسم التطبيق هو **المتجر العالمي سوريا**، ومدة الإعلان المروّج ثابتة على **7 أيام**.

## Android

على حاسوب مثبت عليه Flutter وAndroid Studio:

```bash
cd mobile
flutter pub get
flutter doctor
flutter build apk --release --dart-define=API_BASE_URL=https://عنوان-الخلفية-المستقلة
```

للاختبار المباشر على هاتف Android:

```bash
flutter devices
flutter run --dart-define=API_BASE_URL=http://عنوان-الحاسوب-المحلي:4000
```

لرفع نسخة إلى Google Play استخدم صيغة AAB:

```bash
flutter build appbundle --release --dart-define=API_BASE_URL=https://عنوان-الخلفية-المستقلة
```

قبل النشر يجب إنشاء مفتاح توقيع Android وحفظه خارج المشروع، ثم إعداد `key.properties` محليًا. لا ترسل كلمة مرور المفتاح ولا ترفع ملفات `.jks` أو `key.properties` إلى Git.

## iPhone

بناء iPhone يحتاج macOS وXcode وحساب Apple Developer. بعد فتح المشروع على جهاز Mac:

```bash
cd mobile
flutter pub get
flutter build ios --release --dart-define=API_BASE_URL=https://عنوان-الخلفية-المستقلة
```

بعد ذلك افتح مشروع iOS في Xcode، اختر Team الخاص بحساب Apple Developer، واضبط Bundle Identifier مستقلًا مثل:

```text
sy.almatjar.alami.app
```

ثم اختبر على جهاز iPhone أو Simulator، وأنشئ Archive من Xcode لرفعه إلى App Store Connect. لا يمكن إنشاء توقيع iPhone من هاتف Android أو من Linux وحده.

## الاختبار من هاتف Android

إذا كان Node.js يعمل على الحاسوب والهاتف على شبكة Wi-Fi نفسها، لا تستخدم `localhost` داخل التطبيق. استخدم عنوان IPv4 للحاسوب، مثل:

```text
http://192.168.1.20:4000
```

يجب أن يسمح جدار الحماية بالمنفذ 4000. في محاكي Android استخدم `http://10.0.2.2:4000`.

## متطلبات الخلفية

قبل تشغيل التطبيق يجب تشغيل PostgreSQL وترحيل المخطط، ثم تشغيل Node.js:

```bash
cd backend
npm install
npm run db:migrate
npm start
```

اختبر الخادم من الحاسوب:

```bash
curl http://localhost:4000/health
```

## ما لا يوضع في المشروع

لا تضع كلمات مرور PostgreSQL، أو أسرار JWT، أو مفاتيح Sham Cash/iCash، أو مفاتيح توقيع Android/iPhone داخل ملفات Flutter أو Git. الدفع اليدوي فقط مفعّل حاليًا، وSham Cash وiCash مؤجلان حتى تجهيز الحسابات والربط الرسمي والاختبار والمراجعة القانونية.
